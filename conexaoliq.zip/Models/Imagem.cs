﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CTX.Bot.ConexaoLiq.Models
{
    public class Imagem
    {
        public string Caminho { get; set; }
    }
}