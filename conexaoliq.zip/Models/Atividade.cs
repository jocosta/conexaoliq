﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CTX.Bot.ConexaoLiq.Models
{
    public class Atividade
    {
        public string Inicio { get; set; }

        public string Fim { get; set; }

        public string Descricao { get; set; }

        public string Responsavel { get; set; }
    }
}