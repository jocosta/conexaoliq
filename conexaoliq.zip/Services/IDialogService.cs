﻿using System.Threading.Tasks;

namespace CTX.Bot.ConexaoLiq.Services
{
    public interface IDialogService
    {

        Task Processar();

    }
}